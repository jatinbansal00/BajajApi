const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

app.post('/bfhl', (req, res) => {
    try {
        const { array, user_id, email_id, college_roll_number } = req.body;

        if (!array || !user_id || !email_id || !college_roll_number) {
            throw new Error('Missing required fields in the request body');
        }

        const evenNumbers = [];
        const oddNumbers = [];
        const uppercaseAlphabets = [];

        array.forEach(element => {
            if (typeof element === 'number') {
                if (element % 2 === 0) {
                    evenNumbers.push(element);
                } else {
                    oddNumbers.push(element);
                }
            } else if (typeof element === 'string' && /^[A-Za-z]$/.test(element)) {
                uppercaseAlphabets.push(element.toUpperCase());
            }
        });

        const response = {
            status: 'Success',
            user_id: user_id.replace(/ /g, '_'),
            email_id,
            college_roll_number,
            even_numbers: evenNumbers,
            odd_numbers: oddNumbers,
            uppercase_alphabets: uppercaseAlphabets
        };

        res.status(200).json(response);
    } catch (error) {
        console.error(error);
        res.status(400).json({ status: 'Failed', error: error.message || 'Internal server error' });
    }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});